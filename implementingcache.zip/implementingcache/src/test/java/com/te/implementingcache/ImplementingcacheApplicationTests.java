package com.te.implementingcache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImplementingcacheApplicationTests {

	@Test
	void contextLoads() {
	}

}
